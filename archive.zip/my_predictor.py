# This is the file that you will modify to implement the scoring for your own algorithm.

from __future__ import print_function

import io
import os
import pandas as pd
import pickle

prefix = '/opt/ml/'
model_path = os.path.join(prefix, 'model')

# A singleton for holding the model. This simply loads the model and holds it.
# It has a predict function that does a prediction based on the model and the input data.

class ScoringService(object):
    # Where we keep the model when it's loaded.
    model = None

    # Get the model object for this instance, loading it if it's not already loaded.
    @classmethod
    def get_model(cls):
        if cls.model == None:
            with open(os.path.join(model_path, 'decision-tree-model.pkl'), 'rb') as inp:
                cls.model = pickle.load(inp)
        return cls.model

    # For the input, do the predictions and return them.
    # Args:
    # input: A Pandas data frame. The data on which to do the predictions. There will be
    #        one prediction per row in the dataframe.
    @classmethod
    def predict(cls, input):
        clf = cls.get_model()
        return clf.predict(input)

# Health check. Return healthy if model can be loaded.
def ping_fn():
    return ScoringService.get_model()

# Do an inference on a single batch of data. In this sample server, we take data as CSV, convert
# it to a Pandas data frame for internal use and then convert the predictions back to CSV which really
# just means one prediction per line, since there's a single column.
def predict_fn(request):
    data = None

    # Convert from CSV to Pandas data frame.
    if request.content_type == 'text/csv':
        data = request.data.decode('utf-8')
        s = io.StringIO(data)
        data = pd.read_csv(s, header=None)
    else:
        return None

    print('Invoked with {} records'.format(data.shape[0]))

    # Do the prediction.
    predictions = ScoringService.predict(data)

    # Convert from Numpy back to CSV.
    out = io.StringIO()
    pd.DataFrame({'results':predictions}).to_csv(out, header=False, index=False)
    result = out.getvalue()

    return result
