# This is the file that implements a flask server to do inferences.

from __future__ import print_function

import flask

import my_predictor

# The flask app for serving predictions.
app = flask.Flask(__name__)

# Determine if the container is working and healthy. We will defer to the predictor function.
@app.route('/ping', methods=['GET'])
def ping():
    health = my_predictor.ping_fn() is not None

    status = 200 if health else 404
    return flask.Response(response='\n', status=status, mimetype='application/json')

# Do an inference on a single batch of data. We will defer to the predictor function.
@app.route('/invocations', methods=['POST'])
def transformation():
    request = flask.request

    # Do the prediction.
    predictions = my_predictor.predict_fn(request)

    return flask.Response(response=predictions, status=200, mimetype=type)
